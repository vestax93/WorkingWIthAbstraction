package exercise6;

public enum ItemType {
    GOLD,
    GEM,
    CASH
}
