package exercise4;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
